const apiKey = "c198d7227eec491bad0140904252709";
const apiUrl = "http://api.weatherapi.com/v1/forecast.json?key=";

async function getWeather() {
  const city = document.getElementById("cityInput").value;
  if (!city) {
    alert("Please enter a city name!");
    return;
  }

  try {
    const response = await fetch(`${apiUrl}${apiKey}&q=${city}&days=5&aqi=no&alerts=no`);
    const data = await response.json();

    if (data.error) {
      document.getElementById("weatherResult").innerHTML =
        `<p>${data.error.message}</p>`;
      return;
    }

    // 🌞 Dynamic background
    const isDay = data.current.is_day;
    if (isDay === 1) {
      document.body.style.background = "linear-gradient(to right, #4facfe, #00f2fe)";
    } else {
      document.body.style.background = "linear-gradient(to right, #141e30, #243b55)";
    }

    // 🌍 Current weather
    document.getElementById("weatherResult").innerHTML = `
      <h2>${data.location.name}, ${data.location.country}</h2>
      <img src="https:${data.current.condition.icon}" alt="Weather Icon">
      <p><strong>Condition:</strong> ${data.current.condition.text}</p>
      <p><strong>Temperature:</strong> ${data.current.temp_c}°C</p>
      <p><strong>Humidity:</strong> ${data.current.humidity}%</p>
      <p><strong>Wind Speed:</strong> ${data.current.wind_kph} kph</p>
    `;

    // 📅 5-day forecast
    let forecastHTML = "";
    data.forecast.forecastday.forEach(day => {
      forecastHTML += `
        <div class="forecast-day">
          <h3>${day.date}</h3>
          <img src="https:${day.day.condition.icon}" alt="Icon">
          <p>${day.day.condition.text}</p>
          <p>🌡️ ${day.day.avgtemp_c}°C</p>
          <p>💧 ${day.day.avghumidity}%</p>
        </div>
      `;
    });

    document.getElementById("forecast").innerHTML = forecastHTML;

  } catch (error) {
    document.getElementById("weatherResult").innerHTML =
      "<p>Could not fetch weather data. Please try again.</p>";
  }
}
